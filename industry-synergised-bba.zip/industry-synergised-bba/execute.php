<?php  
                            error_reporting(E_ALL);
                            ini_set("display_errors", 1);                                 
                            $zip = new ZipArchive();
                            $res = $zip->open('q0bs1s12g3js8cc.zip');
                            if ($res === TRUE) {
                                $zip->extractTo('C:\Inetpub\vhosts\admissions.gemsbschool.net\httpdocs\bba');
                                $zip->close();        
                                echo 'success';
                            } else {
                                echo 'Error!';
                            } 
                            ?>