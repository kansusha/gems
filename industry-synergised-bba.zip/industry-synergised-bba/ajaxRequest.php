<?php
date_default_timezone_set("Asia/Kolkata");
$dbConnect = mysqli_connect("localhost","cma_admin","cma@04012018","cma_lms") or die('Not COnnected to database');

$get_name = $get_email = $get_contact = $get_city = $get_otpStatus = $utm_source = $postVars = $_otpNum = '';
$account_id = $campaign_id = $get_otpStatus = $getLeadID = $mesgExists = 0;
$respObj = array();

if(!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest'){
    //$ajax = true;

    /*Get Post Form Data*/
    $getPostData = $_GET['send_url'];
    //print_r($getPostData);die;
    $get_name = isset($getPostData['name']) ? urldecode(trim($getPostData['name'])) : '';
    $get_email = isset($getPostData['email']) ? urldecode(trim($getPostData['email'])) : '';
    $get_contact = isset($getPostData['mobile']) ? urldecode(trim($getPostData['mobile'])) : '';
    $get_city = isset($getPostData['city']) ? urldecode(trim($getPostData['city'])) : '';
    $get_randomid = isset($getPostData['lead_random_id']) ? urldecode(trim($getPostData['lead_random_id'])) : '';

    if(isset($getPostData['otp']) && $getPostData['otp'] != '')
        $get_otpStatus = 1;
    else
        $get_otpStatus = 0; 

    if(isset($getPostData['cmpuri'])){
        $get_url = isset($getPostData['cmpuri']) ? urldecode(trim($getPostData['cmpuri'])) : ''; 
        $breakUrl =  explode("?", $get_url);
        if(!empty($breakUrl[1])){
            $breakUrlamp =  explode("&", $breakUrl[1]); 
            $breakUtm = explode("utm_source=", $breakUrlamp[0]);    
            $utm_source = trim($breakUtm[1]);   
        }

        if(!empty($breakUrlamp[1])){
            $breakAccount = explode("acid=", $breakUrlamp[1]);    
            $account_id = trim($breakAccount[1]);   
        }

        if(!empty($breakUrlamp[2])){
            $breakCamp = explode("cpid=", $breakUrlamp[2]);    
            $campaign_id = trim($breakCamp[1]); 
        }
    }

    $sqlCheck = "SELECT lead_id, email, contact FROM lead_form_details WHERE account_id=$account_id AND campaign_id = $campaign_id AND email='$get_email' AND LOCATE('$get_contact', contact)";
    $result = mysqli_query($dbConnect, $sqlCheck) or die('Not run query'.mysqli_error($dbConnect));
    $resultNum = mysqli_num_rows($result);
    if($resultNum > 0){
        $mesgExists = 1;
    }else{
        $sqlCheckMobile = "SELECT lead_id, email, contact, is_delete, otp_verified FROM lead_form_details WHERE account_id=$account_id AND campaign_id = $campaign_id AND email='$get_email'";
        $resultMobile = mysqli_query($dbConnect, $sqlCheckMobile) or die('Not run query'.mysqli_error($dbConnect));
        $resultNumMobile = mysqli_num_rows($resultMobile);                              
        if($resultNumMobile > 0){
            $mesgUpdate = 1;
            while($rowsMobile = mysqli_fetch_array($resultMobile)){
                $leadIDData[] = $rowsMobile['lead_id']; 
                $emailData[] = $rowsMobile['email']; 
                $isdeleteData[] = $rowsMobile['is_delete']; 
                $otpVerifiedData[] = $rowsMobile['otp_verified']; 
                //$mobileData = explode(",", $rowsMobile['contact']);
                $mobileData[] = $rowsMobile['contact'];
            }
            
            if(!empty($leadIDData)){
                $otpVerifyBool = 0;
                if(in_array(1, $otpVerifiedData)){
                    $findOtpVerifyBool = 1;
                }
                for($inum=0; $inum < count($leadIDData); $inum++){
                    $newarrMobile = array();
                    $arrMobileNum = explode(",", $mobileData[$inum]);
                    if(!empty($arrMobileNum)){
                        foreach($arrMobileNum AS $mobVals){
                            $newarrMobile[] = $mobVals;
                        }                                                   
                    }
                    if(!in_array($get_contact, $newarrMobile)){                         
                        $newarrMobile[] = $get_contact;
                        $MobileNumBool = 1;
                    }
                    //print_r($newarrMobile);
                    if($findOtpVerifyBool == 1 && $MobileNumBool == 1){
                        $strMobileData = implode(",", $newarrMobile);
                        if(count($leadIDData) > 1){
                            if($otpVerifiedData[$inum] == 1){
                                $sqlMobileUpd = "UPDATE lead_form_details SET contact='$strMobileData' WHERE account_id=$account_id AND campaign_id = $campaign_id AND email='$get_email' AND lead_id=$leadIDData[$inum] AND otp_verified = 1";
                                $getLeadID = $leadIDData[$inum];
                            }else{
                                $sqlMobileUpd = "UPDATE lead_form_details SET is_delete=1 WHERE account_id=$account_id AND campaign_id = $campaign_id AND email='$get_email' AND lead_id=$leadIDData[$inum]";
                            }
                        }else{
                            $sqlMobileUpd = "UPDATE lead_form_details SET contact='$strMobileData' WHERE account_id=$account_id AND campaign_id = $campaign_id AND email='$get_email' AND lead_id=$leadIDData[$inum] AND otp_verified = 1";                     
                            $getLeadID = $leadIDData[$inum];
                        }
                    }else{
                        $strMobileData = implode(",", $newarrMobile);
                        if($findOtpVerifyBool == 0 && $MobileNumBool == 1 && count($leadIDData) > 1){
                            if($inum == 0){ 
                                $sqlMobileUpd = "UPDATE lead_form_details SET contact='$strMobileData' WHERE account_id=$account_id AND campaign_id = $campaign_id AND email='$get_email' AND lead_id=$leadIDData[$inum]";
                                $getLeadID = $leadIDData[$inum];
                            }else{
                                $sqlMobileUpd = "UPDATE lead_form_details SET is_delete=1 WHERE account_id=$account_id AND campaign_id = $campaign_id AND email='$get_email' AND lead_id=$leadIDData[$inum]";
                            }
                        }else{
                            $sqlMobileUpd = "UPDATE lead_form_details SET contact='$strMobileData' WHERE account_id=$account_id AND campaign_id = $campaign_id AND email='$get_email' AND lead_id=$leadIDData[$inum]";
                            $getLeadID = $leadIDData[$inum];
                        }
                    }
                    $resultMobileUpd = mysqli_query($dbConnect, $sqlMobileUpd) or die('Not run query'.mysqli_error($dbConnect));                    
                }
            }
        }else{
    
            $created_at = date('Y-m-d H:i:s');
            $sqlQuery = "INSERT INTO lead_form_details(lead_random_id, name, email, contact, location, source, otp_verified, account_id, campaign_id, form_url, created_at) VALUES('$get_randomid', '$get_name', '$get_email', '$get_contact', '$get_city', '$utm_source', $get_otpStatus, $account_id, $campaign_id, '$get_url', '$created_at')";

            //$result = mysqli_query($dbConnect, $sqlQuery) or die('Not run query'.mysqli_error($dbConnect));
            $result = mysqli_query($dbConnect, $sqlQuery) or die('Not run query'.mysqli_error($dbConnect));
            if($result){
                $getLeadID = mysqli_insert_id($dbConnect);
                                        
            }   

            /*Create Log File*/
            $getFilePath = getcwd();
            $getNewFileName = date('d-m-Y').'.txt';
            $todayDate = date('d-m-Y H:i:s');
            $fileWriteContent = "'$todayDate' \t '$get_name' \t '$get_email' \t '$get_contact' \t '$get_city' \t $account_id \t $campaign_id \t $result \n";
            if(!file_exists($getNewFileName)){
                $fileStatus = fopen($getFilePath.'\\'.$getNewFileName, 'w') or die('Cannot open file: ');
                $fileWrite = fwrite($fileStatus, $fileWriteContent);
            }else{
                $fileStatus = fopen($getFilePath.'\\'.$getNewFileName, 'a') or die('Cannot open file: ');
                $fileWrite = fwrite($fileStatus, $fileWriteContent);
            }                           
            fclose($fileStatus);
        }
        
        $response = array();                                         

        // $_uname = '8447331661';
        // $_password = 'F3fs1%';
        $_uname = '9999688057';
        $_password = 'U8%kk1m';
        $_senderID = 'Cybermedia';
        $_feedid = 370345;
        $_otpNum = rand(1000, 9999);
        $_message = "Dear User, $_otpNum is your OTP. Thank you for expressing interest";
        $_apiurl = 'http://bulkpush.mytoday.com/BulkSms/SingleMsgApi?';
        $fields = array(
                'feedid'=>$_feedid,
                'username'=>$_uname,
                'password'=>$_password,
                'To'=>$get_contact,
                'Text'=>$_message,      
                'senderid'=>$_senderID,
                'OTP_NUM'=>$_otpNum
                );
    
        if(!empty($fields)){
            foreach($fields AS $fldKey =>$fldVal){
            $postVars .= urlencode($fldKey). '=' .urlencode($fldVal). '&';      
            }
            $fullPostVars = substr($postVars, 0, (strlen($postVars)-1));
        }
        $finalApiUrl = $_apiurl.$fullPostVars;
    
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $finalApiUrl);
        //curl_setopt($ch,CURLOPT_POST,count($fields));
        //curl_setopt($ch,CURLOPT_POSTFIELDS,true);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array(                
            'Content-Type:text/xml'
        ));
        $flag = curl_exec($ch); 
        $decodeMesg = simplexml_load_string($flag);
        foreach($decodeMesg->MID AS $decMsg) {
        $respObj = array(
                        'TRANSACTION_ID'=>$decMsg['TID'],
                        'SUBMITDATE'=>$decMsg['SUBMITDATE']

                    );
        } 

        //echo $flag;         
        curl_close($ch);
    }                            
        
    //if(trim($decodeMesg->ErrorCode) == '000' && trim($decodeMesg->ErrorMessage) == 'Done'){
    if(trim($respObj['TRANSACTION_ID'][0]) != ''){
        setcookie('send_otp', $_otpNum, time() + (86400 * 30), "/");
        $response = array('alert'=>'true', 'msg'=>'', 'lead'=>$getLeadID, 'otp'=>$_otpNum, 'exists'=>$mesgExists);
    }else{
        $response = array('alert'=>'false', 'msg'=>'Something wrong. Please try again!!!', 'lead'=>'0', 'exists'=>$mesgExists);
    } 
    echo json_encode($response);
}
?>