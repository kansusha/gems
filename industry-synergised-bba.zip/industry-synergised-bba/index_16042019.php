<!DOCTYPE html>
<!-------=====SRT====---------->
<html lang="en">
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
		<meta charset="utf-8">
		<title>GEMS B SCHOOL</title>
		<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
		<meta name="HandheldFriendly" content="true">
		<meta name="MobileOptimized" content="320">
		<meta name="keywords" content="bba colleges bangalore, bba admissions in bangalore, bangalore colleges for bba, list of bba colleges in bangalore, list of colleges in bangalore offering bba, list of colleges in bangalore for bba, one year bba in bangalore, bba colleges in bangalore, best bba colleges in bangalore, bba colleges in bangalore, colleges offering bba in bangalore, bba admission in bangalore college, list of bba colleges in bangalore with address, top 10 bba college in bangalore, new college bangalore bba, bba college bangalore, bba admission in bangalore institute, top bba schools in bangalore, top ten bba colleges in bangalore, top 10 bba college in bangalore, bba colleges in bangalore, bba in bangalore university, degree of bba in bangalore, bangalore bba colleges list, bba in bangalore colleges list, best colleges for bba in bangalore, bba program in bangalore, top b schools in bangalore for bba, bba college bangalore, admissions in bba bangalore, good bba colleges in bangalore, bba colleges in bangalore, bba bangalore, best bba college in bangalore, bba course bangalore, top colleges in bangalore for bba, top bba colleges in bangalore ranking, bba institutes in bangalore, bba courses in bangalore colleges, bba course in bangalore, degree for bba in bangalore, bba in bangalore, bangalore bba college, bba correspondence in bangalore, bba b schools in bangalore, bba programs in bangalore, bangalore bba college, list of top 10 bba colleges in bangalore, list of colleges in bangalore offering bba, bba institute in bangalore, top colleges for bba in bangalore, bba courses list in bangalore, best college for bba in bangalore, best colleges for bba in bangalore, bba college in bangalore, best colleges in bangalore for bba, top bba schools in bangalore, bba courses list in bangalore, bangalore bba colleges list, bba in bangalore university, top ten bba colleges in bangalore, bba courses in loyola college bangalore, top b schools in bangalore for bba, bba in bangalore university, bba admission in bangalore, list of bba college in bangalore, top 10 bba colleges in bangalore, top bba program in bangalore, which university is best for bba in bangalore, which college is best for bba in bangalore, bangalore top bba colleges, bba in bangalore university, bba admission bangalore, top bba college in bangalore, top 10 colleges in bangalore for bba, one year bba in bangalore, top bba colleges in bangalore under tancet, bba admission 2018 in bangalore, bangalore bba, bba universities in bangalore, top bba colleges in bangalore, list of top bba colleges in bangalore, bba courses in bangalore, bba courses bangalore, top 10 colleges in bangalore for bba, bba admission bangalore, list of top 10 bba colleges in bangalore, top bba institutes in bangalore, top bba program in bangalore, bba top colleges in bangalore, bba institute in bangalore, best college in bangalore for bba, top bba colleges in bangalore 2018, list of bba colleges in bangalore, bba colleges in bangalore under madras university, bba colleges of bangalore, bba colleges in bangalore, best bba college in bangalore, bba best colleges in bangalore, bba institute in bangalore, bba in bangalore colleges, list of bba colleges in bangalore, bba courses in bangalore, top ten bba colleges in bangalore, which college is best for bba in bangalore, best colleges for bba in bangalore, colleges in bangalore for bba, bangalore colleges for bba, bba admission 2018 in bangalore, bba admission in bangalore, bba top colleges in bangalore, bba admission 2018 in bangalore, business schools in bangalore for bba, bba admission in bangalore, bba admission in bangalore university, bba colleges in bangalore university, top bba schools in bangalore, bba courses in loyola college bangalore, bangalore top bba colleges, bba admissions in bangalore, top bba colleges in bangalore, bba colleges bangalore, bba colleges in bangalore list, admission for bba in bangalore, best bba colleges in bangalore, bba course in bangalore, top 10 colleges for bba in bangalore, best bba colleges in india, bbm degree, bba admission in india, bba admission forms, bbm college, bachelors in business administration, top bba colleges, bba degree in india, bachelor of business administration bba, bachelor's degree in business administration, top 10 bbm colleges in india, list of bba colleges, best college for bba in india, bbm colleges in india, bba program, top 10 bba colleges india, best college for bbm, best bbm colleges in india, degree in business administration, top bba colleges india, best college for bba, bachelor in business administration, bbm college in india, bba admission test, top bba programs, degree in business, degree in business management, top 10 bba colleges, best bba colleges, direct admission in bba, BBA Admissions, top bba institute, top ten bba colleges in india, top bba college in india, degree in business admin, top 10 colleges for bba in india, top colleges for bbm, bbm program, integrated bba and mba, bba instituite, bachelor degree business administration, top bba college, bbm admission, list of top bba colleges in india, bba colleges india, admissions in bba, best colleges in india for bba, top 20 bba colleges in india, business management degrees, bba admission 2018, bba college in india, bba mba integrated, bachelor degree in business administration, bachelors degree in business administration, top colleges in india for bba, bachelors degree in business, bba admission requirements, top colleges for bba, admission in bba, bbm course details, top 10 bba colleges in india, best bba institutes in india, list of bba colleges in india, bachelor degree in business, top 10 colleges for bba, bba colleges in india, bba admission form, best bba institute, college for bbm, graduate degree in business, best colleges for bba, best bba college, best bba college in india, best colleges for bbm, college for bba, best college for bbm in india, top 50 bba colleges in india, admission form for bba, degree in business studies, bachelor business administration, integrated bba, bachelor's degree in business, bba colleges of india, bachelor of business administration, bba addmission, admission to bba"><link href="http://fonts.googleapis.com/css?family=Lato" rel="stylesheet" type="text/css"><meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1"><link href="css/bootstrap.min.css" rel="stylesheet" type="text/css"><link href="css/skg.css" rel="stylesheet" type="text/css"><link href="css/jquery.bxslider.css" rel="stylesheet" type="text/css"><script src="js/jquery-1.10.2.min.js" type="text/javascript"></script><script src="js/bootstrap.min.js" type="text/javascript"></script><script src="js/jquery.bxslider.js" type="text/javascript"></script>
		  <link href="css/font-awesome.min.css" rel="stylesheet">
		<!-- Google Tag Manager -->
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-P5Z9W9');</script>
<!-- End Google Tag Manager -->

<?php
$currentURL = $_SERVER[REQUEST_URI];
$split_curr_url = parse_url($currentURL);
parse_str($split_curr_url['query'], $split_query_str);

if($split_query_str['adcopy'] == '100010'){
?>
<!-- Global site tag (gtag.js) - Google AdWords: 878471178 -->
<script async src="https://www.googletagmanager.com/gtag/js?id=AW-878471178"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'AW-878471178');
</script>
<?php }else{
?>

<!-- Global site tag (gtag.js) - Google AdWords: 878471178 -->
<script async src="https://www.googletagmanager.com/gtag/js?id=AW-878471178"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'AW-878471178');
</script>
<?php } ?>
	</head>
	<body>
	<div class="container-fluid bg">
		<div class="row">
			<div class="col-md-4 top1" align="center">
				<img src="img/logo.png" width="" class="img-responsive top"></div>
			
		<div align="center" class="col-md-4 top1">
			<font size="5" color="#EE3035"><b>Industry Synergised BBA </b> </font><br><!--<a href="tel:9319746447"><i style="    font-size: 20px;
    color: #363890;" class="fa fa-phone" aria-hidden="true"></i> &nbsp; <strong><font size="4" color="#363890">+91-9319746447</font></strong></a>--></div>
			<div align="center" class="col-md-4 hideme">
				<h3><b>Admissions Season 2019</b><br><font color="#363890" size="3"><b>Full Time Degree (Bangalore)</b></font></h3>
			</div>
		</div>
		
		<div class="row">	
			<div class="carousel slide" id="carousel-example-generic" data-ride="carousel" data-interval="3000">
				  <!-- Indicators -->
			

				  <!-- Wrapper for slides -->
				  <div class="carousel-inner" role="listbox">
					<div class="item active">
					  <img src="img/pic1.jpg"><!--<div class="carousel-caption">
						<font size="6" color="#fff">MASS COMMUNICATION</font>
					  </div>--></div>
					<div class="item">
					  <img src="img/pic2.jpg" alt="..."></div>
						<div class="item">
					  <img src="img/pic3.jpg" alt="..."></div>
						<div class="item">
					  <img src="img/pic4.jpg" alt="..."></div>
					
				  </div>

		<!-- Controls -->
				  <a class="left carousel-control" href="#carousel-example-generic" role="button" data-slide="prev">
					<span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
					<span class="sr-only">Previous</span>
				  </a>
				  <a class="right carousel-control" href="#carousel-example-generic" role="button" data-slide="next">
					<span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
					<span class="sr-only">Next</span>
				  </a>
				</div>
				
			<div align="center" class="lead">
			<h4><b>Get a call back from our <br>Course Expert</b></h4>
				<iframe src="form.php" width="300" height="350" frameborder="0"></iframe>
			</div>	
		</div>
		
		<div align="center" class="row tb">
			<div class="col-md-4">
				<div class="maintab4" data-toggle="modal" data-target=".bs-4-modal-lg" type="button">
				<font size="5"><b>About </b> <br>GEMS B SCHOOL</font>
				</div>
			</div>
			<div class="col-md-4">
				<div class=" maintab5" data-toggle="modal" data-target=".bs-5-modal-lg" type="button">
					<font size="5"><b>Industry Synergised</b> <br>BBA Courses</font>
				</div>
			</div>
			<div class="col-md-4">
				<div class=" maintab2" data-toggle="modal" data-target=".bs-1-modal-lg" type="button">
					<font size="5"><b>Eligibility For </b> <br>BBA</font>
				</div>
			</div>
		</div>
		
		
			<div class="row">
			<div class="col-md-10 col-md-offset-1">
				<div class="col-md-3"><br><br><br><img src="img/gems.png" class="img-responsive"></div>
				<div class="col-md-9"><br><h2> <font color="#3B3B91"><b>Programme Concept</b></font></h2>
							<ul>
								<li>Study a Full Time Dual BBA Degree by attending classes Monday to Friday.</li>
<li>One BBA degree will be awarded by a Globally recognised International University and the other will be from a UGC recognised Indian University.</li>
<li>Alongside the BBA course, students will also be put on 4 hands-on Internships to gain Industry exposure.</li>
<li>At the end of the BBA course, the student will have a Dual BBA degree, 4 Internship certificates and a Job Placement with a reputed company related to the chosen specialisation. </li>
<li>Fees payable in 6 easy instalments. Hostel accommodation available in the campus.</li>



															</ul>
							<!-- <h4 class="cud"> <font color="red"><b>Students also have an option of studying only the BBA course. Pursuing MBA is not compulsory.</b></font></h4> -->
							<h5 class="extra">This is the only program in India where students get to choose from 10 different specialisations. Students can now graduate with a BBA degree in any one of these specialisations and start a career in the area of their choice. </h5>
							<p>The specialisations offered are:</p>
							<div class="col-md-6">
								<ul>
							<li>Marketing Management </li>
							<li>Financial Management</li>
							<li>Human Resource Management</li>
							<li>International Business Management</li>
							<li>Information Systems Management</li>
							<li>Retail Management</li>
						</ul>
							</div>
							<div class="col-md-6">
								<ul>
							<li>Event Management</li>
							<li>Hospitality & Travel Tourism</li>
							<li>Entrepreneurship Management</li>
							<li>Healthcare & Hospital Administration</li>
							<li>Aviation Management</li>
						</ul>
					</div>
				</div>
			</div>
		</div>
		
			<div align="center" class="row alu">
			<h2>Salient Features</h2><br><div class="col-md-12">
				<div class="col-md-2 brd">
					<font size="5">Wi-Fi</font><br><font size="4">Campus</font>
				</div>
				<div class="col-md-2 brd">
					<font size="5">Faculty</font><br><font size="4">from Industry</font>
				</div>
				<div class="col-md-2 brd">
					<font size="5">Digital </font><br><font size="4">Library</font>
				</div>
				<div class="col-md-2 brd">
					<font size="5">Team </font><br><font size="4">Building</font>
				</div>
				<div class="col-md-2 brd">
					<font size="5">Free </font><br><font size="4">Laptops</font>
				</div>
				<div class="col-md-2 ">
					<font size="5">Experiential  </font><br><font size="4">Learning</font>
				</div>
			</div>
			
			<div class="col-md-12"><br><br><div class="col-md-2 brd">
					<font size="5">Outbound </font><br><font size="4">Workshops</font>
				</div>
				<div class="col-md-2 brd">
					<font size="5">Creative</font><br><font size="4">Focus</font>
				</div>
				<div class="col-md-2 brd">
					<font size="5">Industrial  </font><br><font size="4">Visits</font>
				</div>
				<div class="col-md-2 brd">
					<font size="5">Highly  </font><br><font size="4">flexible</font>
				</div>
				<div class="col-md-2 brd">
					<font size="5">Industry   </font><br><font size="4">Relevant Curriculum</font>
				</div>
				<div class="col-md-2">
					<font size="5">Aptitude  </font><br><font size="4"> Test Skills</font>
				</div>
			</div>
		</div>


		
	
	<div class="trophy">
	<div class="container">
		<div class="row">
			<div class="clearfix">
				
			</div>
			
			<div class="col-md-12">
				<h2><font color="#000">Awards</font></h2>
				 <div class="h4-box">
	<p>GEMS B SCHOOL-Bangalore, in Feb 2019, received the prestigious ASSOCHAM award for ‘The most preferred B School of the year in South India’ from Sri. Suresh Prabhu, Central Minister for Industry and Commerce and Civil Aviation and in the presence of Sri. Pranab Mukherjee, former president of India, in New Delhi.  </p>
	</div>
				<div class="col-md-12">
					<div class="col-md-6">
						<img src="img/trophy.jpg">
					</div>
					<div class="col-md-6">
						 <img src="img/people.jpg">
					</div>
				
				
		
			<div class="clearfix">
				
			</div>
		</div>
	</div>
	</div>
	</div>
	</div>
	<div class="row">
			<div align="center" class="col-md-12">
				<h2><font color="#000">PLACEMENTS</font></h2>
				<ul class="colleges"><li><img src="img/c1.jpg"></li>
					<li><img src="img/c2.jpg"></li>
					<li><img src="img/c3.jpg"></li>
					<li><img src="img/c4.jpg"></li>
					<li><img src="img/c5.jpg"></li>
					<li><img src="img/c6.jpg"></li>
					<li><img src="img/c7.jpg"></li>
					<li><img src="img/c8.jpg"></li>
					<li><img src="img/c9.jpg"></li>
					<li><img src="img/c10.jpg"></li>
					<li><img src="img/c11.jpg"></li>
					<li><img src="img/c12.jpg"></li>
				</ul><br></div>
		</div>
		
		
		<div class="row footer">
			<div class="row rowtest">
				<div class="col-md-10 col-md-offset-1">
					<h2 align="center">Testimonials</h2><hr>
					<div class="col-md-6">
						<div class="media media-testimonial">
					  		<div class="media-left pull-left">
								<a href="#"><img src="img/debi.jpg"></a>
					  		</div>
					  		<div class="media-body">
								<p>
									"My name is Debi; I am from Bhubaneswar. It has been a pleasant experience here at GEMS B School. I was delivered what I was promised. I joined the college, sent for interviews and cracked backing with some genuine referrals from my management team. I am sure one can expect turn of events around here. One would certainly get what one has hoped for. If anyone is planning to join Gems B School, I am sure you are heading in the right direction. Good Luck."
								</p>
								<div class="media-attribution"><em>Debi Prasad Dash</em> - American Express Services India Ltd.</div>
					  		</div>
						</div>
					</div>
			
					<div class="col-md-6">
						<div class="media media-testimonial">
					  		<div class="media-left pull-left">
								<a href="#"><img src="img/prashant.jpg"></a>
					  		</div>
					  		<div class="media-body">
								<p>
									Thank you GEMS B school for initiating this program. I am glad to be a part of this reputed institution. The placement cell here has got excellent cooperation with various companies which is of a great advantage for the students. Thank you again.
								</p>
								<div class="media-attribution"><em>Prashant Kumar Singh</em> - JP MORGAN &amp; CHASE</div>
					  		</div>
						</div>
					</div>
				</div>
			</div>

			<div align="center" class="col-md-12"><hr>
				<a href="http://admissions.gemsbschool.net/landing/gems-corporate/?utm_source=google&acid=600014&cpid=35&matchtype={matchtype}&keyword={keyword}&source={ifsearch:S}{ifcontent:D}&target={target}&placement={placement}&device={device}&creative={creative}&{devicemodel}" class="cud cud2">Students who are 12th pass and are above 21yrs of age, can apply for our Corporate BBA course. Click <u style="color:yellow; font-weight:bold; ">here</u> for more details.</a>
				<br><!--<a href="tel:9319746447">&nbsp; <strong><font size="3" color="#fff">Call Us : +91-9319746447</font></strong></a>-->
			<p><br>Great Eastern Management School, Royal Cottage, The Bangalore Palace, Vasanthnagar, Bangalore - 560052<br>Copyright &copy; 2018 GEMS B SCHOOL | All Rights Reserved.</p>
			</div>
		</div>
	</div>
	
					
		<script>
			$(document).ready(function() {
			 $('[data-toggle="tooltip"]').tooltip()
			 
			
			
				  
				  
				   $('.main').bxSlider({
				     pager: false,
					  auto: true,
					autoControls: true,
					minSlides: 1,
					  maxSlides: 4,
					  slideWidth: 330,
					  slideMargin: 10,
					  speed: 300
				  });
				  // Sales Items JS Ends here
				   $('.colleges').bxSlider({
					minSlides: 8,
					  maxSlides: 4,
					  slideWidth: 330,
					  slideMargin: 10,
					  ticker: true,
					  speed: 35000
				  });
				  
				
			});
	</script><!----------------------------------><!----------------------------------><div class="modal fade bs-4-modal-lg" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel">
					  <div class="modal-dialog modal-lg">
						<div class="modal-content col-md-12">
						  <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">x&nbsp;</span></button>
						 <img src="img/p1.jpg" class="img-responsive"><br><div class="col-md-12">
							<h3>About <font color="#3B3B91">GEMS B SCHOOL</font></h3>
					<p><b>GEMS B SCHOOL</b> was conceived back in 2006 by a bunch of industry professionals who firmly believed, Management cannot be learnt in a classroom alone. To understand management concepts effectively, It must be learnt in a blended manner, partly in the Industry and rest of it in the classroom. This led to GEMS B School&rsquo;s pioneering the Earn While You Learn/ Work-Study programs in India where students learn 70% of the course in the organization they work with and 30% in the classroom. GEMS B School is currently ranked in the top 25 business schools in India as per various ranking surveys and their students work with over 350 companies in Bangalore.</p>
						  
						   </div>
						</div>
					  </div>
					</div>
	<!---------------------------------->
			<!---------------------------------->
					<div class="modal fade bs-5-modal-lg" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel">
					  <div class="modal-dialog modal-lg">
						<div class="modal-content col-md-12">
						  <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">x&nbsp;</span></button>
						 <img src="img/p4.jpg" class="img-responsive"><br><div class="col-md-12">
						   <h3><font size="5"><b>Industry Synergised</b> BBA</font></h3>
						   <p><b>3 year full time Industry Synergised BBA</b></p>
						   <div class="col-md-6">
						   <ul><li>Marketing Management </li>
								<li>Financial Management</li>
								<li>Human Resource Management</li>
								<li>International Business Management</li>
								<li>Information Systems Management</li>
								<li>Retail Management</li>
								
							</ul></div>
							  <div class="col-md-6">
								  <ul><li>Event Management</li>
									<!--<li>Investment Management</li>-->
									<li>Hospitality & Travel Tourism</li>
									<li>Entrepreneurship Management</li>
									<!--<li>Export Management</li>
									<li>Services Management</li>-->
									<li>Healthcare & Hospital Administration</li>
									<li>Aviation Management</li> 
								</ul></div>
								
						   </div>
						</div>
					  </div>
					</div>
	<!---------------------------------->
	<!---------------------------------->
					<div class="modal fade bs-1-modal-lg" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel">
					  <div class="modal-dialog modal-lg">
						<div class="modal-content col-md-12">
						  <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">x&nbsp;</span></button>
						 <img src="img/p4.jpg" class="img-responsive"><br><div class="col-md-12">
						  <h3>Eligibility</h3>
							<ul><li>Students with a Plus 2/12th in any stream can apply.</li>
							<li>Students awaiting their Plus 2/12th results can also apply.</li>
							<li>Students will have to clear the GEMS online admission test.</li>
							<!-- <li>Students also have an option of studying only the BBA course. Pursuing MBA is not compulsory.</li>-->
							</ul></div>
						</div>
					  </div>
					</div>

					<!-- Google Tag Manager (noscript) -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-P5Z9W9"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) -->

	<!---------------------------------->
		<!-- Google Code for Remarketing Tag -->
<!--------------------------------------------------
Remarketing tags may not be associated with personally identifiable information or placed on pages related to sensitive categories. See more information and instructions on how to setup the tag on: http://google.com/ads/remarketingsetup
--------------------------------------------------->
<script type="text/javascript">
/* <![CDATA[ */
var google_conversion_id = 947455818;
var google_custom_params = window.google_tag_params;
var google_remarketing_only = true;
/* ]]> */
</script><script src="//www.googleadservices.com/pagead/conversion.js" type="text/javascript">
</script><noscript>
&amp;amp;amp;lt;div style="display:inline;"&amp;amp;amp;gt;
&amp;amp;amp;lt;img height="1" width="1" style="border-style:none;" alt="" src="//googleads.g.doubleclick.net/pagead/viewthroughconversion/947455818/?value=0&amp;amp;amp;amp;amp;guid=ON&amp;amp;amp;amp;amp;script=0"/&amp;amp;amp;gt;
&amp;amp;amp;lt;/div&amp;amp;amp;gt;
</noscript>
<!-- Google Code for Remarketing Tag -->
<!--------------------------------------------------
Remarketing tags may not be associated with personally identifiable information or placed on pages related to sensitive categories. See more information and instructions on how to setup the tag on: http://google.com/ads/remarketingsetup
--------------------------------------------------->
<script type="text/javascript">
/* <![CDATA[ */
var google_conversion_id = 935944573;
var google_custom_params = window.google_tag_params;
var google_remarketing_only = true;
/* ]]> */
</script><script src="//www.googleadservices.com/pagead/conversion.js" type="text/javascript">
</script><noscript>
&amp;amp;amp;lt;div style="display:inline;"&amp;amp;amp;gt;
&amp;amp;amp;lt;img height="1" width="1" style="border-style:none;" alt="" src="//googleads.g.doubleclick.net/pagead/viewthroughconversion/935944573/?value=0&amp;amp;amp;amp;amp;guid=ON&amp;amp;amp;amp;amp;script=0"/&amp;amp;amp;gt;
&amp;amp;amp;lt;/div&amp;amp;amp;gt;
</noscript>

<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-52931454-1', 'auto');
  ga('send', 'pageview');

</script></body></html>
