<?php
  
 $getRandomID = $getLeadid = $getdbRandomid = $conversionBool = 0;
 if(isset($_GET['randid'])){
    $getRandomID = (isset($_GET['randid']) ? $_GET['randid'] : '');
    $getLeadid = (isset($_GET['ldid']) ? $_GET['ldid'] : '');
 }
 //die;
$dbConnect = mysqli_connect("localhost","cma_admin","cma@04012018","cma_lms") or die('Not COnnected to database');
$sqlCheck = "SELECT lead_random_id FROM lead_form_details WHERE lead_id=$getLeadid";
$result = mysqli_query($dbConnect, $sqlCheck) or die('Not run query'.mysqli_error($dbConnect));
if($result){
        $row_result = mysqli_fetch_row($result);
        $getdbRandomid = $row_result[0];

}

if($getdbRandomid == $getRandomID){
    $conversionBool = 1;
}else{
    $conversionBool = 0;
}
 
$currentURL = $_SERVER[REQUEST_URI];
$split_curr_url = parse_url($currentURL);
parse_str($split_curr_url['query'], $split_query_str); 
 
 ?>
 <script>
  fbq('track', 'Lead');
</script>

<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <title>Thank You Page</title>
        <meta charset="UTF-8">
        <meta http-equiv="refresh" content="5; url=http://gemsbschool.com/" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="css/bootstrap.min.css">
        <?php if($conversionBool == 1){ if($split_query_str['adcopy'] == '100010'){ ?>

        <!-- Global site tag (gtag.js) - Google AdWords: 878471178 -->
        <script async src="https://www.googletagmanager.com/gtag/js?id=AW-878471178"></script>
        <script>
          window.dataLayer = window.dataLayer || [];
          function gtag(){dataLayer.push(arguments);}
          gtag('js', new Date());

          gtag('config', 'AW-878471178');
        </script>

        <!-- Global site tag (gtag.js) - Google Ads: 642968960 -->
<script async src="https://www.googletagmanager.com/gtag/js?id=AW-642968960"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'AW-642968960');
</script>

        <?php }else{ ?>
        <!-- Global site tag (gtag.js) - Google AdWords: 932345486 -->
        <script async src="https://www.googletagmanager.com/gtag/js?id=AW-932345486"></script>
        <script>
          window.dataLayer = window.dataLayer || [];
          function gtag(){dataLayer.push(arguments);}
          gtag('js', new Date());

          gtag('config', 'AW-932345486');
        </script>
		
		
		<!-- Global site tag (gtag.js) - Google Ads: 878471178 -->
		<script async src="https://www.googletagmanager.com/gtag/js?id=AW-878471178"></script>
		<script>
		  window.dataLayer = window.dataLayer || [];
		  function gtag(){dataLayer.push(arguments);}
		  gtag('js', new Date());

		  gtag('config', 'AW-878471178');
		</script>

		<!-- Global site tag (gtag.js) - Google Ads: 642968960 -->
<script async src="https://www.googletagmanager.com/gtag/js?id=AW-642968960"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'AW-642968960');
</script>

        <?php } 
        }?>
    </head>
    <body>
        <?php if($conversionBool == 1){ if($split_query_str['adcopy'] == '100010'){ ?>
        <!-- Event snippet for New Conversion conversion page -->
        <script>
          gtag('event', 'conversion', {'send_to': 'AW-878471178/1a_FCOCJ7oIBEIrQ8aID'});
        </script>
        <!-- Event snippet for Submit lead form conversion page -->
<script>
  gtag('event', 'conversion', {'send_to': 'AW-642968960/_Df-CPaQgc8BEIDby7IC'});
</script>

        <?php }else{ ?>
        <!-- Event snippet for Gems BBA+ MBA conversion page -->
        <script>
          gtag('event', 'conversion', {'send_to': 'AW-932345486/CmDECPDlp2MQju3JvAM'});
        </script>

        <!-- Event snippet for Submit lead form conversion page -->
<script>
  gtag('event', 'conversion', {'send_to': 'AW-642968960/_Df-CPaQgc8BEIDby7IC'});
</script>

        <?php } 
        }?>
        <div class="jumbotron text-xs-center" style="text-align: center;background:none;">
            <h1 class="display-3" style="color:#e63900;">THANK YOU!</h1>
            <h5>Thank you for your interest in programs offered by GEMS B SCHOOL. Due to high flow of enquiries, there may be a delay in getting in touch with you. However, Our Executive - Student Relations will positively get in touch with you within 3 working days, please bear with us. To have the details and seek clarifications immediately, please feel free to contact us on the below mentioned numbers, between 10 am and 7 pm from Monday to Saturday.</h5><hr>
            <h5>+91-9632205138, +91-9845125069, +91-9591724397, +91-9980288869, 080-23560387/89</h5>
</div>
</body>
</html>