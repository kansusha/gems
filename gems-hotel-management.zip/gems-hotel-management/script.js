
        $(document).ready(function(){
            var find_search = window.parent.location.href;
            var adcopy_urlVal = getParamValuesByName('adcopy');
            //console.log(find_search);
            $("#cmpuri").val(find_search);
            $('#frmsubmit').on("click", function(e) {
                if(e.which==13){
                     formValidator(e);
                }
            });

            $('#frmsubmit').on("click", function(){
                formValidator();
            });

            $("#add-break-tag").html('<br/>');
            $("#adcopy_value").val(adcopy_urlVal);
        });
            var otp_request_sent=false;
            function send_otp(){    
                var checkMobile = $.trim($("#id_mobile").val());
                if(checkMobile == ''){
                    $("#error").show();
                    $("#error").html('Please enter valid mobile number.');
                    return false;
                }else{
                    $("#error").hide();
                    $("#error").html('');
                }

                $("#id_otp_button").html("Re-Send OTP");
                //var getMobOtp = $.trim($("#mobile").val());
                //var params = 'mobile_num='+encodeURI(getMobOtp)+'&option=otpnum';

                var frmPostData = $("form").serializeArray();
                var send_url = {};
                if(frmPostData != ''){
                    $.each(frmPostData, function(i, field){
                        send_url[field.name]= field.value;
                    });
                }

                $.ajax({
                    type: 'GET',        
                    url: 'api/get-otp/',
                    data: { send_url:send_url },
                    success: function(res) {
                        //alert('hi');
                        //console.log(res.alert);
                        //otp send success
                        var decodeJson = JSON.parse(res);
                        if (decodeJson.alert == 'false') {
                            $("#error").show();
                            $("#error").html(decodeJson.msg);
                        }else{
                            //alert('OK');
                            $("#lead_id").val(decodeJson.lead);
                        }

                    },
                    error:function(){
                        otp_request_sent=false;
                   
                    }
               
                });
                return false;
            }

        function formValidator(){
            console.log(document.forms[0].getElementsByTagName("select"));
            var frmInput = document.forms[0].getElementsByTagName("input");
            var frmSelect = document.forms[0].getElementsByTagName("select");var getCookieOtp = getCookie('send_otp');var arrInputName = [];
            var arrInputType = [];
            var arrInputValue = [];

            if(frmInput.length > 0){
                for(var inum = 0; inum < frmInput.length; inum++){
                    if(frmInput[inum].attributes['required'] && frmInput[inum].attributes['required'].specified){
                        arrInputName.push(frmInput[inum].attributes['id'].nodeValue);
                        arrInputValue.push(frmInput[inum].value);
                        arrInputType.push(frmInput[inum].attributes['type'].nodeValue); 
                    }else if(frmInput[inum].attributes['id'] && $.trim(frmInput[inum].attributes['id'].nodeValue) == 'id_otp'){
                        arrInputName.push(frmInput[inum].attributes['id'].nodeValue);
                        arrInputValue.push(frmInput[inum].value);
                        arrInputType.push(frmInput[inum].attributes['type'].nodeValue); 
                    }
                }
            }if(frmSelect.length > 0){
                for(var snum = 0; snum < frmSelect.length; snum++){
                    if(frmSelect[snum].attributes['required'] && frmSelect[snum].attributes['required'].specified){
                        arrInputName.push(frmSelect[snum].attributes['id'].nodeValue);
                        arrInputValue.push(frmSelect[snum].value);
                        arrInputType.push('select');    
                    }
                    
                }
            }

            if(arrInputName.length > 0){
                for(var vnum=0; vnum < arrInputName.length; vnum++){
                    if(arrInputType[vnum] == 'text' && arrInputName[vnum] == 'id_name' && !isValidName(arrInputValue[vnum])){
                        $("#error").show();
                        $("#error").html('Please enter valid name');
                        return false;
                    }else if((arrInputType[vnum] == 'email' || arrInputType[vnum] == 'text') && arrInputName[vnum] == 'id_email' && arrInputValue[vnum] == ''){
                        $("#error").show();
                        $("#error").html('Please enter valid email');
                        return false;
                    }else if((arrInputType[vnum] == 'email' || arrInputType[vnum] == 'text') && arrInputName[vnum] == 'id_email' && !isValidEmailAddress(arrInputValue[vnum])){
                        $("#error").show();
                        $("#error").html('Please enter valid email');
                        return false;
                    }else if((arrInputType[vnum] == 'text' || arrInputType[vnum] == 'tel') && arrInputName[vnum] == 'id_mobile' && !isValidMobileNumber(arrInputValue[vnum])){
                        $("#error").show();
                        $("#error").html('Please enter valid mobile number');
                        return false;
                    }else if(arrInputType[vnum] == 'select' && arrInputValue[vnum] == ''){
                        $("#error").show();
                        $("#error").html('Please select '+arrInputName[vnum]);
                        return false;
                    }else if(arrInputType[vnum] == 'text' && arrInputValue[vnum] == ''){
                        $("#error").show();
                        $("#error").html('Please enter '+arrInputName[vnum]+ ' field with valid input');
                        return false;
                    }else if(arrInputType[vnum] == 'text' && arrInputName[vnum] == 'id_otp' && getCookieOtp != arrInputValue[vnum]){
                        $("#error").show();
                        $("#error").html('Entered otp not matched');
                        return false;
                    }else{
                        $("#error").hide();
                        $("#error").html('');
                    }
                }
            }

    
            var frmPostData = $("form").serializeArray();
            var send_url = {};
                if(frmPostData != ''){
                    $.each(frmPostData, function(i, field){
                        send_url[field.name]= field.value;
                    });
            }
            //console.log(send_url);
            //return false;
            $.ajax({        
                type:'GET',
                crossDomain: true,
                contentType: "application/json; charset=utf-8",
                url:"http://cmgalaxy.com/post_lead_data",
                data: { send_url:send_url },
                dataType:"jsonp",
                jsonp: 'callback',
                jsonpCallback: 'jsonpCallback',
                success:function(){
                    
                    //var getJson = JSON.parse(resp);
                    
                },
                async: false,
                cache: false 
            });
        }

        function jsonpCallback(data){
            window.parent.location.href="http://admissions.gemsbschool.net/landing/gems-hotel-management/thanks.php?randid="+data.randomid+"&ldid="+data.leaddata+"&adcopy="+data.adcopy; 
        }

        function isValidName(name) {
            var re = /^[a-zA-Z].*$/; //only charecters in name
            if (name.match(re)) {
                return true;
            }
            return false;
        }


        function isValidEmailAddress(emailAddress) {
            var pattern = new RegExp(/^(("[\w-\s]+")|([\w-]+(?:\.[\w-]+)*)|("[\w-\s]+")([\w-]+(?:\.[\w-]+)*))(@((?:[\w-]+\.)*\w[\w-]{0,66})\.([a-z]{2,6}(?:\.[a-z]{2})?)$)|(@\[?((25[0-5]\.|2[0-4][0-9]\.|1[0-9]{2}\.|[0-9]{1,2}\.))((25[0-5]|2[0-4][0-9]|1[0-9]{2}|[0-9]{1,2})\.){2}(25[0-5]|2[0-4][0-9]|1[0-9]{2}|[0-9]{1,2})\]?$)/i);
            return pattern.test(emailAddress);
        }
        function ValidateInteger(objEle) {
            var strString = GetElementValue(objEle);
            var strChar;
            var strValidChars = '0123456789';
            var blnResult = true;
            // test strString consists of valid characters listed above
            for (i = 0; i < strString.length && blnResult == true; i++) {
                strChar = strString.charAt(i);
                if (strValidChars.indexOf(strChar) == -1) {
                    blnResult = false;
                }
            }
            return blnResult;
        }

        function GetElementValue(objEle) {
            var result = '';
            switch (objEle.type) {
                case "text":
                case "hidden":
                case "textarea":
                case "password":
                    result = objEle.value;
                    break;

                case "select-one":
                case "select-multiple":
                case "select":
                    if (objEle.selectedIndex >= 0) {
                        result = objEle.options[objEle.selectedIndex].value;
                        if (result == -1 || result == '') {
                            result = '';
                        }
                    }
                    break;

                case "radio":
                case "checkbox":
                    for (var i = 0; i < objEle.form.elements.length; i++) {
                        if (objEle.form.elements[i].name == objEle.name) {
                            if (objEle.form.elements[i].checked) {
                                result += objEle.form.elements[i].value + ",";
                            }
                        }
                    }
                    break;
                case "tel":
                    result = objEle.value;
                    break;

            }
            return result;
        }



        function isValidMobileNumber(number, maxlength) {
            maxlength = parseInt(maxlength) || 10;
            if (maxlength == 10)
                var re = /^[7-9]\d{9}$/; //10 digit mobile number starting with 7,8 or 9
            else
                var re = /^\d{15}$/
            if (number.match(re)) {
                return true;
            }
            return false;
        }


        function isInteger(s) {
            var i;
            if (s.length > 10 || s.length < 10)
                return false;
            for (i = 0; i < s.length; i++) {
                // Check that current character is number.
                var c = s.charAt(i);
                if (((c < "0") || (c > "9"))) return false;
            }
            // All characters are numbers.
            return true;
        }
        function getCookie(cname) {
            var name = cname + "=";
            var decodedCookie = decodeURIComponent(document.cookie);
            var ca = decodedCookie.split(";");
            for(var i = 0; i <ca.length; i++) {
                var c = ca[i];
                while (c.charAt(0) == ' ') {
                    c = c.substring(1);
                }
                if (c.indexOf(name) == 0) {
                    return c.substring(name.length, c.length);
                }
            }
            return "";
        }
        function getParamValuesByName (querystring) {
            var qstring = window.parent.location.href.slice(window.parent.location.href.indexOf('?') + 1).split('&');
            for (var i = 0; i < qstring.length; i++) {
                var urlparam = qstring[i].split('=');
                if (urlparam[0] == querystring) {
                    return urlparam[1];
                }
            }
        }