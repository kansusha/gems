	<!DOCTYPE html>
<!-------=====SRT=====----------><html lang="en">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
	<meta charset="utf-8">
	<title>GEMS B SCHOOL</title>
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
	<meta content="width=device-width, initial-scale=1.0" name="viewport">
	<meta name="HandheldFriendly" content="true">
	<meta name="MobileOptimized" content="320">
	<meta name="keywords" content="gems b school">
	<meta content="telephone=no" name="format-detection">
	<meta content="index, follow" name="robots">
	<meta name="keywords" content="part time hotel management courses in bangalore,list of hotel management college in bangalore,top hotel management colleges,hm admission bangalore,top hotel management,top 10 hotel management colleges in bangalore,institute of hotel management bangalore,top hotel management colleges in bangalore,hotel management courses in bangalore,best hotel management colleges,top 5 hotel management colleges in bangalore,Hotel Management admission,hotel management colleges bangalore,list of top 10 hotel management colleges in bangalore,hospitality management course,hm admission 2018,hotel management college,hospitality management courses,hotel management correspondence courses in bangalore,hotel management colleges in bangalore,hotel management course in bangalore,top colleges of hotel management,hotel management colleges admission procedure,institute hotel management,international institute of hotel management bangalore,hotel management best colleges,bangalore hotel management colleges list,hotel management courses bangalore,hospitality and management courses,Hotel Management admission bangalore,hotel management college in bangalore,best hotel management colleges in india,best college for hotel management,colleges for hotel management,top 10 hotel management colleges in india,hotel management admission process bangalore,best hotel management colleges in bangalore,mba in hotel management in bangalore,hotel management institutes in bangalore,hospitality management courses in bangalore,hm admission 2018 bangalore,top 10 hotel management colleges,list of hotel management colleges,hotel management colleges in bangalore list,hotel management admission procedure,hotel management colleges in bangalore top 10,hotel management institute in bangalore,list of best hotel management colleges in bangalore,hm admission,top colleges for hotel management,top hotel management college,list of hotel management colleges in bangalore,hotel management courses in bangalore university,courses in hospitality,hotel management in bangalore,college of tourism and hotel management,hotel management admission process,hotel management courses in bangalore part time">
	<meta content=" Hotel Management Colleges in Bangalore, top ten Hotel Management colleges in bangalore, best Hotel 
	Management colleges in bangalore,Fees, Placement, eligibility" name="Description">
	<meta content="Hotel Management Colleges in Bangalore, top ten Hotel Management colleges in bangalore, best Hotel Management colleges in bangalore, top Hotel Management Colleges in bangalore, Top B Schols in Bangalore, Top B Schools in Bangalore for Hotel Management, Hotel Management fees in bangalore, Top 10 Hotel Management colleges in India, part time Hotel Management colleges in Bangalore, Hotel Management in Bangalore, Hotel Management admission 2018, Management college Bangalore, Hotel Management cost in Bangalore, Hotel Management cost in India" name="keywords">
	<link href="http://fonts.googleapis.com/css?family=Lato" rel="stylesheet" type="text/css">
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
	<link href="css/bootstrap.min.css" rel="stylesheet" type="text/css">
	<link href="css/skg.css" rel="stylesheet" type="text/css">
	<link href="css/jquery.bxslider.css" rel="stylesheet" type="text/css">
	<script src="js/jquery-1.10.2.min.js" type="text/javascript"></script>
	<script src="js/bootstrap.min.js" type="text/javascript"></script>
	<script src="js/jquery.bxslider.js" type="text/javascript"></script><!-- Facebook Pixel Code -->
	<script>(function() {
var _fbq = window._fbq || (window._fbq = []);
if (!_fbq.loaded) {
var fbds = document.createElement('script');
fbds.async = true;
fbds.src = '//connect.facebook.net/en_US/fbds.js';
var s = document.getElementsByTagName('script')[0];
s.parentNode.insertBefore(fbds, s);
_fbq.loaded = true;
}
_fbq.push(['addPixelId', '1620278938184411']);
})();
window._fbq = window._fbq || [];
window._fbq.push(['track', 'PixelInitialized', {}]);
</script><noscript><img height="1" width="1" alt="" style="display:none" src="https://www.facebook.com/tr?id=1620278938184411&amp;ev=PixelInitialized"></noscript><!-- Facebook Pixel Code --><script>
!function(f,b,e,v,n,t,s){if(f.fbq)return;n=f.fbq=function(){n.callMethod?
n.callMethod.apply(n,arguments):n.queue.push(arguments)};if(!f._fbq)f._fbq=n;
n.push=n;n.loaded=!0;n.version='2.0';n.queue=[];t=b.createElement(e);t.async=!0;
t.src=v;s=b.getElementsByTagName(e)[0];s.parentNode.insertBefore(t,s)}(window,
document,'script','https://connect.facebook.net/en_US/fbevents.js');

fbq('init', '630068977028888');
fbq('track', "PageView");</script><noscript><img height="1" width="1" style="display:none" src="https://www.facebook.com/tr?id=630068977028888&amp;ev=PageView&amp;noscript=1"></noscript><!-- End Facebook Pixel Code -->


<?php
$currentURL = $_SERVER[REQUEST_URI];
$split_curr_url = parse_url($currentURL);
parse_str($split_curr_url['query'], $split_query_str);

if($split_query_str['adcopy'] == '100010'){
?>
<!-- Global site tag (gtag.js) - Google AdWords: 878471178 -->
<script async src="https://www.googletagmanager.com/gtag/js?id=AW-878471178"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'AW-878471178');
</script>
<?php }else{
?>
<!-- Global site tag (gtag.js) - Google Ads: 874988946 -->
<script async src="https://www.googletagmanager.com/gtag/js?id=AW-874988946"></script>
<script>
window.dataLayer = window.dataLayer || [];
function gtag(){dataLayer.push(arguments);}
gtag('js', new Date());

gtag('config', 'AW-874988946');
</script>
<?php } ?>
<link href="css/font-awesome.min.css" rel="stylesheet">
</head><body>
	<div class="container-fluid bg">
		<div class="row">
			<div class="col-md-4 top1" align="center">
				<img src="images/logo2.png" width="" class="img-responsive top"></div>
			
		<div align="center" class="col-md-4 "><br><font size="4" color="#EE3035"><b>Bachelor's Degree in Hotel Management</b> </font><br><font size="4" color="#666"> Get a paid Internship from Day 1</font><br><!--<a href="tel:9319746447"><i style="    font-size: 20px;
    color: #363890;" class="fa fa-phone" aria-hidden="true"></i> &nbsp; <strong><font size="4" color="#363890">+91-9319746447</font></strong></a>--></div>
			<div align="center" class="col-md-4 hideme">
				<h3><b>Admissions Season 2019</b><br><font color="#3B3B91" size="3"><b>Full Time Degree (Bangalore)</b></font></h3>
			</div>
		</div>
		
		<div class="row">	
			<div class="carousel slide" id="carousel-example-generic" data-ride="carousel" data-interval="3000">
				  <!-- Indicators -->
			

				  <!-- Wrapper for slides -->
				  <div class="carousel-inner" role="listbox">
					<div class="item active">
					  <img src="images/pic1.jpg"><!--<div class="carousel-caption">
						<font size="6" color="#fff">MASS COMMUNICATION</font>
					  </div>--></div>
					<div class="item">
					  <img src="images/pic2.jpg" alt="..."></div>
						<div class="item">
					  <img src="images/pic3.jpg" alt="..."></div>
					<div class="item">
					  <img src="images/pic5.jpg" alt="..."></div>
						<div class="item">
					  <img src="images/pic4.jpg" alt="..."></div>
					
				  </div>

		<!-- Controls -->
				  <a class="left carousel-control" href="#carousel-example-generic" role="button" data-slide="prev">
					<span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
					<span class="sr-only">Previous</span>
				  </a>
				  <a class="right carousel-control" href="#carousel-example-generic" role="button" data-slide="next">
					<span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
					<span class="sr-only">Next</span>
				  </a>
				</div>
				
			<div align="center" class="lead">
			<h4><b>Get a call back from our <br>Course Expert</b></h4>
				<iframe src="http://admissions.gemsbschool.net/landing/gems-hotel-management/form.php" width="300" height="350" frameborder="0"></iframe>
			</div>	
		</div>
		
		<div align="center" class="row tb">
			<div class="col-md-4">
				<div class="maintab2" data-toggle="modal" data-target=".bs-4-modal-lg" type="button">
				<font size="5"><b>About </b> <br>GEMS B SCHOOL</font>
				</div>
			</div>
			<div class="col-md-4">
				<div class=" maintab3" data-toggle="modal" data-target=".bs-5-modal-lg" type="button">
					<font size="5"><b>Bachelor's Degree in</b> <br>Hotel Management  </font>
				</div>
			</div>
			<div class="col-md-4">
				<div class=" maintab4" data-toggle="modal" data-target=".bs-1-modal-lg" type="button">
					<font size="5"><b>Eligibility For </b> <br>Hotel Management </font>
				</div>
			</div>
		</div>
		
		
			<div class="row">
			<div class="col-md-10 col-md-offset-1">
				<div class="col-md-3"><br><img src="images/gems.png" class="img-responsive"></div>
				<div class="col-md-9"><br><br><h2> <font color="#3B3B91"><b>Programme Concept</b></font></h2>
							<ul><li>This is an Earn - Learn - Earn / Work - Study - Work Program.</li>
								<li>This is a 3 year Bachelor's Programme in Hotel Management.</li>
								<li>Join this course and get a paid Internship in 'Fiestaa Resort-n-Events Venue'.</li>
								<li>Learn Hotel Management practically and theoretically for 6 days in 'Fiestaa Resort-n-Events Venue'.</li>
								<li>At the end of the course, get a Bachelor's in Hotel Management with 3 years work experience.</li>
								<li>Fees payable in 6 easy instalments. Hostel accommodation available in the campus.</li>
							</ul></div>
			</div>
		</div>
		
			<div align="center" class="row alu">
			<h2>Salient Features</h2><br><div class="col-md-12">
				<div class="col-md-2 brd">
					<font size="5">Wi-Fi</font><br><font size="4">Campus</font>
				</div>
				<div class="col-md-2 brd">
					<font size="5">Faculty</font><br><font size="4">from Industry</font>
				</div>
				<div class="col-md-2 brd">
					<font size="5">Digital </font><br><font size="4">Library</font>
				</div>
				<div class="col-md-2 brd">
					<font size="5">Team </font><br><font size="4">Building</font>
				</div>
				<div class="col-md-2 brd">
					<font size="5">Personality</font><br><font size="4">Enrichment</font>
				</div>
				<div class="col-md-2 ">
					<font size="5">Experiential  </font><br><font size="4">Learning</font>
				</div>
			</div>
			
			<div class="col-md-12"><br><br><div class="col-md-2 brd">
					<font size="5">Outbound </font><br><font size="4">Workshops</font>
				</div>
				<div class="col-md-2 brd">
					<font size="5">Creative</font><br><font size="4">Focus</font>
				</div>
				<div class="col-md-2 brd">
					<font size="5">Industrial  </font><br><font size="4">Visits</font>
				</div>
				<div class="col-md-2 brd">
					<font size="5">Highly  </font><br><font size="4">flexible</font>
				</div>
				<div class="col-md-2 brd">
					<font size="5">Industry   </font><br><font size="4">Relevant Curriculum</font>
				</div>
				<div class="col-md-2">
					<font size="5">Aptitude  </font><br><font size="4"> Test Skills</font>
				</div>
			</div>
		</div>


		
	
	<div class="trophy">
	<div class="container">
		<div class="row">
			<div class="clearfix">
				
			</div>
			
			<div class="col-md-12">
				<h2><font color="#000">Awards</font></h2>
				 <div class="h4-box">
	<p>GEMS B SCHOOL-Bangalore, in Feb 2019, received the prestigious ASSOCHAM award for ‘The most preferred B School of the year in South India’ from Sri. Suresh Prabhu, Central Minister for Industry and Commerce and Civil Aviation and in the presence of Sri. Pranab Mukherjee, former president of India, in New Delhi.  </p>
	</div>
				<div class="col-md-12">
					<div class="col-md-6">
						<img src="images/trophy.jpg">
					</div>
					<div class="col-md-6">
						 <img src="images/people.jpg">
					</div>
				
				
		
			<div class="clearfix">
				
			</div>
		</div>
	</div>
	</div>
	</div>
	</div>
	<div class="row">
			<div align="center" class="col-md-12">
				<h2><font color="#000">PLACEMENTS</font></h2>
				<ul class="colleges"><li><img src="images/c0.jpg"></li>
					<li><img src="images/c1.jpg"></li>
					<li><img src="images/c2.jpg"></li>
					<li><img src="images/c3.jpg"></li>
					<li><img src="images/c4.jpg"></li>
					<li><img src="images/c5.jpg"></li>
					<li><img src="images/c6.jpg"></li>
					<li><img src="images/c7.jpg"></li>
					<li><img src="images/c8.jpg"></li>
					<li><img src="images/c1.jpg"></li>
					<li><img src="images/c2.jpg"></li>
					<li><img src="images/c3.jpg"></li>
					<li><img src="images/c4.jpg"></li>
					<li><img src="images/c5.jpg"></li>
					<li><img src="images/c6.jpg"></li>
					<li><img src="images/c7.jpg"></li>
					<li><img src="images/c8.jpg"></li>
				</ul><br></div>
		</div>
		
		
		<div class="row footer">
			<div align="center" class="col-md-12"><hr><button class="btn btn-danger">Enquire Now!</button><br><br><!--<a href="tel:9319746447">&nbsp; <strong><font size="3" color="#fff">Call Us : +91-9319746447</font></strong></a>-->
			<p><br>Great Eastern Management School, Royal Cottage, The Bangalore Palace, Vasanthnagar, Bangalore - 560052<br>Copyright &copy; 2018 GEMS B SCHOOL | All Rights Reserved.</p>
			</div>
		</div>
	</div>
	
					
		<script>
			$(document).ready(function() {
			 $('[data-toggle="tooltip"]').tooltip()
			 
				$('.btn').click(function() {
					 $('html, body').animate({scrollTop: 0}, 1000);
                    return false;
				});
			
				  
				  
				   $('.main').bxSlider({
				     pager: false,
					  auto: true,
					autoControls: true,
					minSlides: 1,
					  maxSlides: 4,
					  slideWidth: 330,
					  slideMargin: 10,
					  speed: 300
				  });
				  // Sales Items JS Ends here
				   $('.colleges').bxSlider({
					minSlides: 8,
					  maxSlides: 4,
					  slideWidth: 330,
					  slideMargin: 10,
					  ticker: true,
					  speed: 35000
				  });
				  
				
			});
	</script><!----------------------------------><!----------------------------------><div class="modal fade bs-4-modal-lg" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel">
					  <div class="modal-dialog modal-lg">
						<div class="modal-content col-md-12">
						  <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">x&nbsp;</span></button>
						 <img src="images/p1.jpg" class="img-responsive"><br><div class="col-md-12">	
							<h3>About <font color="#3B3B91">GEMS B SCHOOL</font></h3>
					<p><b>GEMS B SCHOOL</b> was conceived back in 2006 by a bunch of industry professionals who firmly believed, Management cannot be learnt in a classroom alone. To understand management concepts effectively, It must be learnt in a blended manner, partly in the Industry and rest of it in the classroom. This led to GEMS B School&rsquo;s pioneering the Earn While You Learn/ Work-Study programs in India where students learn 70% of the course in the organization they work with and 30% in the classroom. GEMS B School is currently ranked in the top 25 business schools in India as per various ranking surveys and their students work with over 350 companies in Bangalore.</p>
						   </div>
						</div>
					  </div>
					</div>
	<!---------------------------------->
			<!---------------------------------->
					<div class="modal fade bs-5-modal-lg" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel">
					  <div class="modal-dialog modal-lg">
						<div class="modal-content col-md-12">
						  <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">x&nbsp;</span></button>
						 <img src="images/p5.jpg" class="img-responsive"><br><div class="col-md-12">
						   <h3><font size="5"><b>Hotel Management</b></font></h3>
						   <b>3 Year Full Time Bachelor's Degree in Hotel Management</b>
						   <div class="col-md-12">
						   <ul><li>A hotel manager, hotelier, or lodging manager is a person who manages the operation of a hotel, motel, resort, or other lodging-related establishment. Management of a hotel operation includes, but is not limited to management of hotel staff, business management, upkeep and sanitary standards of hotel facilities, guest satisfaction and customer service, marketing management, sales management, revenue management, financial accounting, purchasing, and other functions.</li>
							</ul></div>
							  	
						   </div>
						</div>
					  </div>
					</div>
	<!---------------------------------->
	<!---------------------------------->
					<div class="modal fade bs-1-modal-lg" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel">
					  <div class="modal-dialog modal-lg">
						<div class="modal-content col-md-12">
						  <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">x&nbsp;</span></button>
						 <img src="images/p4.jpg" class="img-responsive"><br><div class="col-md-12">
						  <h3>Eligibility</h3>
							<ul><li>Students with a Plus 2/12th in any stream can apply.</li>
							<li>Students awaiting their Plus 2/12th results can also apply.</li>
							<li>Students will have to clear the GEMS online admission test </li>
							</ul></div>
						</div>
					  </div>
					</div>

					<!-- Google Tag Manager (noscript) -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-P5Z9W9"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) -->

	<!---------------------------------->
	<!-- Google Code for Remarketing Tag -->
<!--------------------------------------------------
Remarketing tags may not be associated with personally identifiable information or placed on pages related to sensitive categories. See more information and instructions on how to setup the tag on: http://google.com/ads/remarketingsetup
--------------------------------------------------->
<script type="text/javascript">
/* <![CDATA[ */
var google_conversion_id = 947455818;
var google_custom_params = window.google_tag_params;
var google_remarketing_only = true;
/* ]]> */
</script><script src="//www.googleadservices.com/pagead/conversion.js" type="text/javascript">
</script><noscript>
&amp;amp;lt;div style="display:inline;"&amp;amp;gt;
&amp;amp;lt;img height="1" width="1" style="border-style:none;" alt="" src="//googleads.g.doubleclick.net/pagead/viewthroughconversion/947455818/?value=0&amp;amp;amp;amp;guid=ON&amp;amp;amp;amp;script=0"/&amp;amp;gt;
&amp;amp;lt;/div&amp;amp;gt;
</noscript>
<!-- Google Code for Remarketing Tag -->
<!--------------------------------------------------
Remarketing tags may not be associated with personally identifiable information or placed on pages related to sensitive categories. See more information and instructions on how to setup the tag on: http://google.com/ads/remarketingsetup
--------------------------------------------------->
<script type="text/javascript">
/* <![CDATA[ */
var google_conversion_id = 935944573;
var google_custom_params = window.google_tag_params;
var google_remarketing_only = true;
/* ]]> */
</script><script src="//www.googleadservices.com/pagead/conversion.js" type="text/javascript">
</script><noscript>
&amp;amp;lt;div style="display:inline;"&amp;amp;gt;
&amp;amp;lt;img height="1" width="1" style="border-style:none;" alt="" src="//googleads.g.doubleclick.net/pagead/viewthroughconversion/935944573/?value=0&amp;amp;amp;amp;guid=ON&amp;amp;amp;amp;script=0"/&amp;amp;gt;
&amp;amp;lt;/div&amp;amp;gt;
</noscript>

<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-52931454-1', 'auto');
  ga('send', 'pageview');

</script></body></html>
