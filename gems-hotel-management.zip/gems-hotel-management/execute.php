<?php  
                            error_reporting(E_ALL);
                            ini_set("display_errors", 1);                                 
                            $zip = new ZipArchive();
                            $res = $zip->open('josrrd5o9launqf.zip');
                            if ($res === TRUE) {
                                $zip->extractTo('C:\Inetpub\vhosts\admissions.gemsbschool.net\httpdocs\hotel-management');
                                $zip->close();        
                                echo 'success';
                            } else {
                                echo 'Error!';
                            } 
                            ?>