<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
	<title>GEMS B SCHOOL</title>
	<meta content="width=device-width, initial-scale=1.0" name="viewport">
	<meta content="true" name="HandheldFriendly">
	<meta content="320" name="MobileOptimized">
	<meta content="telephone=no" name="format-detection">
	<meta content="index, follow" name="robots">
	<meta name="keywords" content="part time hotel management courses in bangalore,list of hotel management college in bangalore,top hotel management colleges,hm admission bangalore,top hotel management,top 10 hotel management colleges in bangalore,institute of hotel management bangalore,top hotel management colleges in bangalore,hotel management courses in bangalore,best hotel management colleges,top 5 hotel management colleges in bangalore,Hotel Management admission,hotel management colleges bangalore,list of top 10 hotel management colleges in bangalore,hospitality management course,hm admission 2018,hotel management college,hospitality management courses,hotel management correspondence courses in bangalore,hotel management colleges in bangalore,hotel management course in bangalore,top colleges of hotel management,hotel management colleges admission procedure,institute hotel management,international institute of hotel management bangalore,hotel management best colleges,bangalore hotel management colleges list,hotel management courses bangalore,hospitality and management courses,Hotel Management admission bangalore,hotel management college in bangalore,best hotel management colleges in india,best college for hotel management,colleges for hotel management,top 10 hotel management colleges in india,hotel management admission process bangalore,best hotel management colleges in bangalore,mba in hotel management in bangalore,hotel management institutes in bangalore,hospitality management courses in bangalore,hm admission 2018 bangalore,top 10 hotel management colleges,list of hotel management colleges,hotel management colleges in bangalore list,hotel management admission procedure,hotel management colleges in bangalore top 10,hotel management institute in bangalore,list of best hotel management colleges in bangalore,hm admission,top colleges for hotel management,top hotel management college,list of hotel management colleges in bangalore,hotel management courses in bangalore university,courses in hospitality,hotel management in bangalore,college of tourism and hotel management,hotel management admission process,hotel management courses in bangalore part time">
	<meta content=" Hotel Management Colleges in Bangalore, top ten Hotel Management colleges in bangalore, best Hotel 
	Management colleges in bangalore,Fees, Placement, eligibility" name="Description">
	<meta content="Hotel Management Colleges in Bangalore, top ten Hotel Management colleges in bangalore, best Hotel Management colleges in bangalore, top Hotel Management Colleges in bangalore, Top B Schols in Bangalore, Top B Schools in Bangalore for Hotel Management, Hotel Management fees in bangalore, Top 10 Hotel Management colleges in India, part time Hotel Management colleges in Bangalore, Hotel Management in Bangalore, Hotel Management admission 2018, Management college Bangalore, Hotel Management cost in Bangalore, Hotel Management cost in India" name="keywords"><link href="css/bootstrap.min.css" rel="stylesheet" type="text/css"><link href="css/temp.css" rel="stylesheet" type="text/css"><link href="css/responsive.css" rel="stylesheet" type="text/css"><link href="sliderjs/bootstrap.css" rel="stylesheet"><script src="js/jquery-1.10.2.min.js" type="text/javascript"></script><script src="js/bootstrap.min.js" type="text/javascript"></script><script>(function() {
var _fbq = window._fbq || (window._fbq = []);
if (!_fbq.loaded) {
var fbds = document.createElement('script');
fbds.async = true;
fbds.src = '//connect.facebook.net/en_US/fbds.js';
var s = document.getElementsByTagName('script')[0];
s.parentNode.insertBefore(fbds, s);
_fbq.loaded = true;
}
_fbq.push(['addPixelId', '1620278938184411']);
})();
window._fbq = window._fbq || [];
window._fbq.push(['track', 'PixelInitialized', {}]);
</script><noscript><img height="1" width="1" alt="" style="display:none" src="https://www.facebook.com/tr?id=1620278938184411&amp;ev=PixelInitialized"></noscript><!-- Facebook Pixel Code --><script>
!function(f,b,e,v,n,t,s){if(f.fbq)return;n=f.fbq=function(){n.callMethod?
n.callMethod.apply(n,arguments):n.queue.push(arguments)};if(!f._fbq)f._fbq=n;
n.push=n;n.loaded=!0;n.version='2.0';n.queue=[];t=b.createElement(e);t.async=!0;
t.src=v;s=b.getElementsByTagName(e)[0];s.parentNode.insertBefore(t,s)}(window,
document,'script','https://connect.facebook.net/en_US/fbevents.js');

fbq('init', '630068977028888');
fbq('track', "PageView");</script><noscript><img height="1" width="1" style="display:none" src="https://www.facebook.com/tr?id=630068977028888&amp;ev=PageView&amp;noscript=1"></noscript><!-- End Facebook Pixel Code -->
<!-- Global site tag (gtag.js) - Google Ads: 874988946 -->
<script async src="https://www.googletagmanager.com/gtag/js?id=AW-874988946"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'AW-874988946');
</script>

<?php
$currentURL = $_SERVER[REQUEST_URI];
$split_curr_url = parse_url($currentURL);
parse_str($split_curr_url['query'], $split_query_str);

if($split_query_str['adcopy'] == '100010'){
?>
<!-- Global site tag (gtag.js) - Google AdWords: 878471178 -->
<script async src="https://www.googletagmanager.com/gtag/js?id=AW-878471178"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'AW-878471178');
</script>
<?php }else{
?>
<!-- Global site tag (gtag.js) - Google Ads: 874988946 -->
<script async src="https://www.googletagmanager.com/gtag/js?id=AW-874988946"></script>
<script>
window.dataLayer = window.dataLayer || [];
function gtag(){dataLayer.push(arguments);}
gtag('js', new Date());

gtag('config', 'AW-874988946');
</script>
<?php } ?>
<link href="css/font-awesome.min.css" rel="stylesheet">
</head><body>
<div class="container-fluid">
<div class="row" style="background: #fff;">
	<div class="col-md-4 col-sm-4 col-xs-12 col-sm-4 col-xs-12">
	<img align="right" src="images/gems.png" class="img-responsive logo"></div>
	<div align="center" class="col-md-4 col-sm-4 col-xs-12"><br><h4><b>Bachelor's Degree in Hotel Management</b><br><font size="4">Get a paid Internship from Day 1</font><br><!--<a href="tel:9319746447"><i style="font-size: 20px;
    color: #363890;" class="fa fa-phone" aria-hidden="true"></i> &nbsp; <strong><font size="4" color="#363890">+91-9319746447</font></strong></a>--></h4>
	</div>
	<div align="center" class="col-md-4 col-sm-4 col-xs-12" id="hideme1">
	<h4 style="font-size:24px; margin-top:20px;"><strong>Admissions Season 2019</strong><br><strong style="color:#3B3B91;">Bangalore</strong></h4>
	</div>
</div>
<div class="row">
<div class="bannermain">
<div class="carousel slide" data-ride="carousel" id="carousel-example-generic">
<!-- Indicators -->
<ol class="carousel-indicators" style="display:none;"><li class="active" data-slide-to="0" data-target="#carousel-example-generic">
<li data-slide-to="1" data-target="#carousel-example-generic">
<li data-slide-to="2" data-target="#carousel-example-generic">
<li data-slide-to="3" data-target="#carousel-example-generic">
<li data-slide-to="4" data-target="#carousel-example-generic">
</ol><!-- Wrapper for slides --><div class="carousel-inner">
	<div class="item active">
	<img src="images/1.jpg" style="border:1px solid #ccc;"><div class="cap">
			<font color="#2E3192" size="5">3 Year Full Time Bachelor's Degree in <b>Hotel Management</b></font>
		</div>
	</div>
	<div class="item">
	<img src="images/2.jpg"><div class="cap">
			<font color="#2E3192" size="5">3 Year Full Time Bachelor's Degree in <b>Hotel Management</b></font>
		</div>
	</div>
	<div class="item">
	<img src="images/3.jpg"><div class="cap">
			<font color="#2E3192" size="5">3 Year Full Time Bachelor's Degree in <b>Hotel Management</b></font>
		</div>
	</div>
	<div class="item">
	<img src="images/4.jpg"><div class="cap">
			<font color="#2E3192" size="5">3 Year Full Time Bachelor's Degree in <b>Hotel Management</b></font>
		</div>
	</div>
</div>
<a class="left carousel-control" data-slide="prev" href="#carousel-example-generic">
<span class="glyphicon glyphicon-chevron-left"></span></a><a class="right carousel-control" data-slide="next" href="#carousel-example-generic"><span class="glyphicon glyphicon-chevron-right">
</span></a>
</div>
<div id="leadform">
<h2 align="center">
<b>Get a Call Back from our Course <br>Expert</b>
</h2>
<iframe frameborder="0" height="350" src="http://admissions.gemsbschool.net/landing/gems-hotel-management/form.php" width="300"></iframe>
<!--<h2><b>Get More Info on:</b><br /><a href="http://www.gemsbschool.com/" target="_blank">www.gemsbschool.com</a></h2>-->
</div>
</div>
</div>
</div>
<div class="container" id="hideme" style="text-align: justify; color: #23236D;">
<div class="row" style="box-shadow: 0px 5px 5px #888888;">
<div class="col-md-7">
<div class="panel panel-default">
<div class="panel-body">
<h2 align="center">
                   Courses Offered 
                </h2>
<div role="tabpanel">
<!-- Nav tabs -->
<ul class="nav nav-tabs" role="tablist" style="font-size:13px;"><li class="active" role="presentation"><a aria-controls="home" data-toggle="tab" href="#home" role="tab">Programme Concept</a></li>
<!--<li role="presentation"><a aria-controls="profile" data-toggle="tab" href="#profile" role="tab">
                            Courses</a></li>-->
<li role="presentation"><a aria-controls="messages" data-toggle="tab" href="#messages" role="tab">
                            Salient Features</a></li>
<li role="presentation"><a aria-controls="settings" data-toggle="tab" href="#settings" role="tab">
                            Eligibility</a></li>
</ul><!-- Tab panes --><div class="tab-content">
<div class="tab-pane fade in active" id="home" role="tabpanel" style="border-radius: 10px; margin-bottom:15px;
                            background: #fff; height: 270px; box-shadow: 0px 0px 10px #888; padding:15px;">
<br><ul><li>This is an Earn - Learn - Earn / Work - Study - Work Program.</li>
<li>This is a 3 year Bachelor's Programme in Hotel Management.</li>
<li>Join this course and get a paid Internship with a reputed Hotel.</li>
<li>Learn Hotel Management practically in the hotel for 5 days and in the classroom for 2 days.</li>
<li>At the end of the course, get a Bachelor's in Hotel Management with 3 years work experience.</li>
<li>Fees payable in 6 easy instalments. Hostel accommodation available in the campus.</li>
</ul></div>
<div class="tab-pane fade" id="profile" role="tabpanel" style="border-radius: 10px;
                            background: #fff; height: 300px; margin-bottom:15px; box-shadow: 0px 0px 10px #888; padding:20px;">
<br><p><b>3 year full time Bachelor's Degree in Hotel Management</b></p>
		<ul><li>A hotel manager, hotelier, or lodging manager is a person who manages the operation of a hotel, motel, resort, or other lodging-related establishment. </li>
		<li>Management of a hotel operation includes, but is not limited to management of hotel staff, business management, upkeep and sanitary standards of hotel facilities.</li> 
		<li>Guest satisfaction and customer service, marketing management, sales management, revenue management, financial accounting, purchasing, and other functions.</li>
</ul></div>
<div class="tab-pane fade" id="messages" role="tabpanel" style="border-radius: 10px;
                            background: #fff; height: 280px; margin-bottom:15px; box-shadow: 0px 0px 10px #888; ">
<br><ul><li>Wi-Fi Campus</li>
<li>Faculty from industry</li>
<li>Digital Library with Unlimited Access</li>
<li>Team Building</li>

<li>Most economical</li>
<li>Outbound Workshops</li>
<li>Creativity</li>
<li>Industrial visits</li>
</ul><ul><li>Highly flexible</li>
<li>Seminars</li>
<li>Entrepreneurship</li>
<li>Classes during Weekends</li>
<li>Student friendly experiential learning</li>
<li>Personality enrichment</li>
<li>Aptitude test skills</li>
<li>Industry Relevant Curriculum</li>
<li>Excellent Environment</li>
</ul></div>
<div class="tab-pane fade" id="settings" role="tabpanel" style="border-radius: 10px;
                            background: #fff;  box-shadow: 0px 0px 10px #888;">
<br><ul><li>Students with a Plus 2/12th in any stream can apply.</li>
<li>Students awaiting their Plus 2/12th results can also apply.</li>
<li>Students will have to clear the GEMS online admission test <br><span>@ <a href="http://www.gemsadmissiontest.com/" target="_blank">www.gemsadmissiontest.com</a></span></li>
</ul></div>
</div>
</div>
</div>
</div>
</div>
<!--tab-->
<!---Top Recruiters--->
<div class="col-md-5">
<div class="panel panel-default" style="box-shadow:0px 0px 10px #888;">
<div class="panel-body">
<ul style="margin-left:-20px;"><h2 align="center">
                Top Recruiters </h2>
<img src="images/logos.jpg" style="padding-left:15px;"></ul></div>
</div>
</div><!---test----->
</div>

<div class="trophy">
	<div class="container">
		<div class="row">
			<div class="clearfix">
				
			</div>
			
			<div class="col-md-12">
				<h2><font color="#000">Awards</font></h2>
				 <div class="h4-box">
	<p>GEMS B SCHOOL-Bangalore, in Feb 2019, received the prestigious ASSOCHAM award for ‘The most preferred B School of the year in South India’ from Sri. Suresh Prabhu, Central Minister for Industry and Commerce and Civil Aviation and in the presence of Sri. Pranab Mukherjee, former president of India, in New Delhi.  </p>
	</div>
				<div class="col-md-12">
					<div class="col-md-6">
						<img src="images/trophy.jpg">
					</div>
					<div class="col-md-6">
						 <img src="images/people.jpg">
					</div>
				
				
		
			<div class="clearfix">
				
			</div>
		</div>
	</div>
	</div>
	</div>
	</div>
	
<!--1st row-
<div class="row why" style="background: #fff; box-shadow: 0px 0px 10px #888;">
<h2 align="center">
                Testimonials</h2>
<hr/>
<p align="center">
<ul>
<li style="background:url(images/debi.jpg) no-repeat;"></li><p><strong>Debi Prasad Dash</strong></p>
<p style="margin:0px 30px 10.5px;">"My name is Debi; I am from Bhubaneswar.

It has been a pleasant experience here at GEMS B School. I was delivered what I was promised. I joined the college, sent for interviews and cracked backing with some genuine referrals from my management team. I am sure one can expect turn of events around here. One would certainly get what one has hoped for. 
If anyone is planning to join Gems B School, I am sure you are heading in the right direction. 
Good Luck."</p>
<p><strong>American Express Services India Ltd.</strong></p>
<li style="background:url(images/prashant.jpg) no-repeat;"></li><p><strong>Prashant Kumar Singh</strong></p>
<p style="margin:0px 30px 10.5px;">Thank you GEMS B school for initiating this program. I am glad to be a part of this reputed institution. The placement cell here has got excellent cooperation with various companies which is of a great advantage for the students. Thank you again.</p>
<p><strong>JP MORGAN &amp; CHASE</strong></p>
</ul>
</p>
</div>-->
</div>

<div class="footer">
<h6 align="center">
<!--<a href="tel:9319746447">&nbsp; <strong><font size="3" color="#fff">Call Us : +91-9319746447</font></strong></a><br><br>-->
            Copyright &copy; 2018 GEMS B SCHOOL | All Rights Reserved <br>
            Great Eastern Management School, Royal Cottage, The Bangalore Palace, Vasanthnagar, Bangalore - 560052</h6>
</div>
<!--<link href="sliderjs/stylesheet.css" rel="stylesheet" />-->
<script src="sliderjs/jquery-1.8.2.js" type="text/javascript"></script><script src="sliderjs/bootstrap.min.js" type="text/javascript"></script><script src="sliderjs/common.js" type="text/javascript"></script><!-- Google Code for Remarketing Tag --><!--------------------------------------------------
Remarketing tags may not be associated with personally identifiable information or placed on pages related to sensitive categories. See more information and instructions on how to setup the tag on: http://google.com/ads/remarketingsetup
---------------------------------------------------><script type="text/javascript">
/* <![CDATA[ */
var google_conversion_id = 947455818;
var google_custom_params = window.google_tag_params;
var google_remarketing_only = true;
/* ]]> */
</script><script type="text/javascript" src="//www.googleadservices.com/pagead/conversion.js">
</script><noscript>
<div style="display:inline;">
<img height="1" width="1" style="border-style:none;" alt="" src="//googleads.g.doubleclick.net/pagead/viewthroughconversion/947455818/?value=0&amp;guid=ON&amp;script=0"></div>
</noscript>

<!-- Google Code for Remarketing Tag -->
<!--------------------------------------------------
Remarketing tags may not be associated with personally identifiable information or placed on pages related to sensitive categories. See more information and instructions on how to setup the tag on: http://google.com/ads/remarketingsetup
--------------------------------------------------->
<script type="text/javascript">
/* <![CDATA[ */
var google_conversion_id = 935944573;
var google_custom_params = window.google_tag_params;
var google_remarketing_only = true;
/* ]]> */
</script><script type="text/javascript" src="//www.googleadservices.com/pagead/conversion.js">
</script><noscript>
<div style="display:inline;">
<img height="1" width="1" style="border-style:none;" alt="" src="//googleads.g.doubleclick.net/pagead/viewthroughconversion/935944573/?value=0&amp;guid=ON&amp;script=0"></div>
</noscript>

<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-52931454-1', 'auto');
  ga('send', 'pageview');

</script></body></html>
